using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace _3DModel
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        private Model model;
        private Matrix world = Matrix.CreateTranslation(new Vector3(0,0,0));
        private Matrix view;// = Matrix.CreateLookAt(new Vector3(0,5,10),new Vector3(0,0,0),Vector3.UnitY);
        private Matrix projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(45),800f / 480f, 0.1f,100f);
        private Vector3 position;
        private float angle;

        Crate box;
        private Crate[,] crate;
        Floor floor;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Map.ReadFile(@"Content\map2.txt");
            model = Content.Load<Model>("Ship");
            position = new Vector3(0,-2.5f,0);
            angle = 0;

            floor = new Floor(Content.Load<Model>(@"floor"), new Vector3(0, -50f, 0));
            box = new Crate(Content.Load<Model>(@"crate2"),new Vector3(-6f,0,0));

            crate = new Crate[30, 30];
            //crate[1, 1] = new Crate(Content.Load<Model>(@"crate2"), new Vector3(-4f, 0, 0));

            for (int x = 0; x <= 29; x++)
            {
                for (int y = 0;y <= 29;y++)
                {
                    //1blue,2green,3red,4white
                    crate[x, y] = new Crate(Content.Load<Model>(@"crate2"), new Vector3(-4f, -6f, 0));
                    crate[x, y].setType(Map.getMapPart(x, y));
                    string modelToLoad = "";
                    if (crate[x, y].getType() == 1)
                        modelToLoad = "blueCrate";
                    else if (crate[x, y].getType() == 2)
                        modelToLoad = "greenCrate";
                    else if (crate[x, y].getType() == 3)
                        modelToLoad = "redCrate";
                    else if (crate[x, y].getType() == 4)
                        modelToLoad = "whiteCrate";
                    else if (crate[x, y].getType() == 11)
                        modelToLoad = "blackCrate";
                    else if (crate[x, y].getType() == 9)
                        modelToLoad = "brownCrate";
                    else if (crate[x, y].getType() == 5)
                        modelToLoad = "blueDoor";
                    else if (crate[x, y].getType() == 6)
                        modelToLoad = "greenDoor";
                    else if (crate[x, y].getType() == 7)
                        modelToLoad = "redDoor";
                    else if (crate[x, y].getType() == 8)
                        modelToLoad = "whiteDoor";
                    else if (crate[x, y].getType() == 10)
                        modelToLoad = "roller";
                    else
                    modelToLoad = "greyCrate";
                    crate[x, y].reloadModel(Content.Load<Model>(@modelToLoad));

                    crate[x,y].setWorldX((x-15)*6);
                    crate[x, y].setWorldZ((y-15)*6);
                    if (crate[x, y].getType() == 11 || crate[x, y].getType() == 5 || crate[x, y].getType() == 10 || crate[x, y].getType() == 6 || crate[x, y].getType() == 7 || crate[x, y].getType() == 8)
                    {
                        Console.Write("Wall Rise");
                        crate[x, y].setWorldY(-1);
                    }
                    if (crate[x, y].getType() == 10)
                    {
                        crate[x, y].setWorldX(crate[x, y].getPosition().X + 1.5f);
                        crate[x, y].setWorldZ(crate[x, y].getPosition().Z + 1.5f);
                        crate[x, y].reloadModelTwo(Content.Load<Model>(@"blackCrate"));
                    }
                    //Console.Write(crate[x, y].getWorld().ToString());
			            //baseTile.y = (ii - 1)*baseTile.height
                       //baseTile.x = (i- (30*(ii- 1)))*baseTile.width
                }
            }

            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();

            if (Keyboard.GetState().IsKeyDown(Keys.W))
            {
                position += new Vector3(0, 0, -1.04f);
                angle = 0f;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.S))
            {
                position += new Vector3(0, 0, 1.04f);
                angle = 3.14159f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.A))
            {
                position += new Vector3(-1.04f, 0, 0);
                angle = 3.14159f/2f;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.D))
            {
                position += new Vector3(1.04f, 0, 0);
                angle = (3.14159f / 2) + 3.14159f;
            }

           // angle += 0.03f;

            Vector3 angleToPush = new Vector3(0, 0, 0);
            if (angle == 0f)
            {
                angleToPush = new Vector3(position.X, position.Y + 2, position.Z + 5);
            }
            else if (angle == 3.14159f)
            {
                angleToPush = new Vector3(position.X, position.Y + 2, position.Z - 5);
            }
            else if (angle == 3.14159f / 2f)
            {
                angleToPush = new Vector3(position.X + 5, position.Y + 2, position.Z);
            }
            else if (angle == (3.14159f / 2f) + 3.14159f)
            {
                angleToPush = new Vector3(position.X - 5, position.Y + 2, position.Z);
            }

            //view = Matrix.CreateLookAt(new Vector3(position.X,position.Y + 20,position.Z + 15),position,Vector3.UnitY);
            view = Matrix.CreateLookAt(angleToPush, position, Vector3.UnitY);
            world = Matrix.CreateRotationZ(angle) * Matrix.CreateRotationX((3.14159f/2)+3.14159f) * Matrix.CreateTranslation(position);
         
            //world = Matrix.CreateTranslation(position);

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            //DrawModel(model, world, view, projection);
            DrawModel(box.getModel(), box.getWorld(), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(6, 0, 0)), view, projection);
            
            /*DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-4, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-6, -2, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(4, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(2, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(0, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-2, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-4, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-6, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(6, -2, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(6, -4, 0)), view, projection);
            */

            //Console.Write(crate[1, 1].getWorld().ToString());
            //Console.Write(crate[2, 2].getPosition().ToString());
            for (int x = 0; x <= 29; x++)
            {
                //Console.Write(x.ToString());
                for (int y = 0; y <= 29; y++)
                {
                    DrawModel(crate[x, y].getModel(), crate[x, y].getWorld(), view, projection);
                    if (crate[x, y].getType() == 10)
                        DrawModel(crate[x, y].getModelTwo(), Matrix.CreateTranslation(new Vector3(crate[x, y].getPosition().X - 1.5f, -6f, crate[x, y].getPosition().Z - 1.5f)), view, projection);
                }
            }
            //DrawModel(floor.getModel(), floor.getWorld(), view, projection);
            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }

        private void DrawModel(Model model,Matrix world,Matrix view,Matrix projection)
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.World = world;
                    effect.View = view;
                    effect.Projection = projection;
                }
                mesh.Draw();
            }
        }
    }
}
