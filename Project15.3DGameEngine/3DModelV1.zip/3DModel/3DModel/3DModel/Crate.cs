﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace _3DModel
{
    class Crate
    {
        private Model model;
        private Model modelTwo;
        private Matrix world = Matrix.CreateTranslation(new Vector3(6, 0, 0));
        private Vector3 position = Vector3.Zero;
        private int crateType = 0;
        
        public Crate(Model theModel,Vector3 whereAt)
        {
            model = theModel;
            world = Matrix.CreateTranslation(whereAt);
            position = whereAt;
        }
        public void reloadModel(Model theModel)
        {
            model = theModel;
        }
        public void reloadModelTwo(Model theModel)
        {
            modelTwo = theModel;
        }
        public void boxUpdate()
        {
            world =  Matrix.CreateTranslation(position);
        }
        public Model getModel()
        {
            return model;
        }
        public Model getModelTwo()
        {
            return modelTwo;
        }
        public Matrix getWorld()
        {
            return world;
        }
        public int getType()
        {
            return crateType;
        }
        public Vector3 getPosition()
        {
            return position;
        }
        public void setType(int type)
        {
            crateType = type;
        }
        public void setWorldX(float x)
        {
            position.X = x;
            world = Matrix.CreateTranslation(position);
        }
        public void setWorldY(float y)
        {
            position.Y = y;
            world = Matrix.CreateTranslation(position);
        }
        public void setWorldZ(float z)
        {
            position.Z = z;
            world = Matrix.CreateTranslation(position);
        }
    }
}
