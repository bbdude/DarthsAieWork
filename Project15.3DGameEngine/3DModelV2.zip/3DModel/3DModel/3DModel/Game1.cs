using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace _3DModel
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private Model model;
        private Matrix world = Matrix.CreateTranslation(new Vector3(0, 0, 0));
        private Matrix view;// = Matrix.CreateLookAt(new Vector3(0,5,10),new Vector3(0,0,0),Vector3.UnitY);
        private Matrix projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(45), 800f / 480f, 0.1f, 100f);
        private Vector3 position;
        private Vector3 angleToPush = new Vector3(0, 20, 15);
        private BoundingBox playerBoundry;

        private float angle;
        private float angleToAdjust = 0;

        private Crate box;
        private Crate[,] crate;
        private Floor floor;
        private Sword sword;
        private Gun gun;
        private Gui gui;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.

            spriteBatch = new SpriteBatch(GraphicsDevice);
            Map.ReadFile(@"Content\map2.txt");
            model = Content.Load<Model>("Ship");
            position = new Vector3(0, -2.5f, 0);
            angle = 0;

            floor = new Floor(Content.Load<Model>(@"floor"), new Vector3(0, -50f, 0));
            box = new Crate(Content.Load<Model>(@"crate2"), new Vector3(-6f, 0, 0));
            sword = new Sword(Content.Load<Model>(@"sword"), position);
            gun = new Gun(Content.Load<Model>(@"gun"), position);
            gui = new Gui();
            gui.loadGui(GraphicsDevice);

            crate = new Crate[30, 30];
            //crate[1, 1] = new Crate(Content.Load<Model>(@"crate2"), new Vector3(-4f, 0, 0));

            for (int x = 0; x <= 29; x++)
            {
                for (int y = 0; y <= 29; y++)
                {
                    //1blue,2green,3red,4white
                    crate[x, y] = new Crate(Content.Load<Model>(@"crate2"), new Vector3(-4f, -6f, 0));
                    crate[x, y].setType(Map.getMapPart(x, y));
                    string modelToLoad = "";
                    if (crate[x, y].getType() == 1)
                        modelToLoad = "blueCrate";
                    else if (crate[x, y].getType() == 2)
                        modelToLoad = "greenCrate";
                    else if (crate[x, y].getType() == 3)
                        modelToLoad = "redCrate";
                    else if (crate[x, y].getType() == 4)
                        modelToLoad = "whiteCrate";
                    else if (crate[x, y].getType() == 11)
                        modelToLoad = "blackCrate";
                    else if (crate[x, y].getType() == 9)
                        modelToLoad = "brownCrate";
                    else if (crate[x, y].getType() == 5)
                        modelToLoad = "blueDoor";
                    else if (crate[x, y].getType() == 6)
                        modelToLoad = "greenDoor";
                    else if (crate[x, y].getType() == 7)
                        modelToLoad = "redDoor";
                    else if (crate[x, y].getType() == 8)
                        modelToLoad = "whiteDoor";
                    else if (crate[x, y].getType() == 10)
                        modelToLoad = "roller";
                    else
                        modelToLoad = "greyCrate";
                    crate[x, y].reloadModel(Content.Load<Model>(@modelToLoad));

                    crate[x, y].setWorldX((x - 15) * 6);
                    crate[x, y].setWorldZ((y - 15) * 6);
                    if (crate[x, y].getType() == 11 || crate[x, y].getType() == 5 || crate[x, y].getType() == 10 || crate[x, y].getType() == 6 || crate[x, y].getType() == 7 || crate[x, y].getType() == 8)
                    {
                        //Console.Write("Wall Rise");
                        crate[x, y].setWorldY(-1);
                    }
                    if (crate[x, y].getType() == 10)
                    {
                        crate[x, y].setWorldX(crate[x, y].getPosition().X + 1.5f);
                        crate[x, y].setWorldZ(crate[x, y].getPosition().Z + 1.5f);
                        crate[x, y].reloadModelTwo(Content.Load<Model>(@"blackCrate"));
                    }
                    //Console.Write(crate[x, y].getWorld().ToString());
                    //baseTile.y = (ii - 1)*baseTile.height
                    //baseTile.x = (i- (30*(ii- 1)))*baseTile.width
                }
            }

            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            playerBoundry = new BoundingBox(position, new Vector3(1, 1, 1));
            MouseState mouse = Mouse.GetState(); ;
            KeyboardState keyboard = Keyboard.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || keyboard.IsKeyDown(Keys.Escape))
                this.Exit();
            Vector2 plannedDirection = Vector2.Zero;

            if (keyboard.IsKeyDown(Keys.W))
            {
                position.X -= changeAngleToVector(angle).X;
                position.Z -= changeAngleToVector(angle).Y;
            }
            else if (keyboard.IsKeyDown(Keys.S))
            {
                position.X += changeAngleToVector(angle).X;
                position.Z += changeAngleToVector(angle).Y;
            }
            if (keyboard.IsKeyDown(Keys.D))
            {
                if (angleToPush.X > 15)
                    angleToPush.X = 15;
                else if (angleToPush.X < -15)
                    angleToPush.X = -15;
                if (angleToPush.Z > 15)
                    angleToPush.Z = 15;
                else if (angleToPush.Z < -15)
                    angleToPush.Z = -15;

                angle -= 0.0206683552631579f;
                if (angleToPush.Z <= 16 + angleToAdjust && angleToPush.Z >= 0 + angleToAdjust && angleToPush.X <= 0 - angleToAdjust && angleToPush.X >= -16 - angleToAdjust)
                {
                    angleToPush.Z -= .2f;
                    angleToPush.X -= .2f;
                }
                if (angleToPush.Z <= 0 - angleToAdjust && angleToPush.Z >= -16 - angleToAdjust && angleToPush.X <= 0 - angleToAdjust && angleToPush.X >= -16 - angleToAdjust)
                {
                    angleToPush.Z -= .2f;
                    angleToPush.X += .2f;
                }
                if (angleToPush.Z <= 0 - angleToAdjust && angleToPush.Z >= -16 - angleToAdjust && angleToPush.X <= 16 + angleToAdjust && angleToPush.X >= 0 + angleToAdjust)
                {
                    angleToPush.Z += .2f;
                    angleToPush.X += .2f;
                }
                if (angleToPush.Z <= 16 + angleToAdjust && angleToPush.Z >= 0 + angleToAdjust && angleToPush.X <= 16 + angleToAdjust && angleToPush.X >= 0 + angleToAdjust)
                {
                    angleToPush.Z += .2f;
                    angleToPush.X -= .2f;
                }
            }
            else if (keyboard.IsKeyDown(Keys.D))
            {
            }
            else if (keyboard.IsKeyDown(Keys.A))
            {
                if (angleToPush.X > 15)
                    angleToPush.X = 15;
                else if (angleToPush.X < -15)
                    angleToPush.X = -15;
                if (angleToPush.Z > 15)
                    angleToPush.Z = 15;
                else if (angleToPush.Z < -15)
                    angleToPush.Z = -15;

                angle += 0.0206683552631579f;
                if (angleToPush.Z <= 16 && angleToPush.Z >= 0 && angleToPush.X >= 0 && angleToPush.X <= 16)
                {
                    angleToPush.Z -= .2f;
                    angleToPush.X += .2f;
                }
                if (angleToPush.Z <= 0 && angleToPush.Z >= -16 && angleToPush.X >= 0 && angleToPush.X <= 16)
                {
                    angleToPush.Z -= .2f;
                    angleToPush.X -= .2f;
                }
                if (angleToPush.Z <= 0 && angleToPush.Z >= -16 && angleToPush.X >= -16 && angleToPush.X <= 0)
                {
                    angleToPush.Z += .2f;
                    angleToPush.X -= .2f;
                }
                if (angleToPush.Z <= 16 && angleToPush.Z >= 0 && angleToPush.X >= -16 && angleToPush.X <= 0)
                {
                    angleToPush.Z += .2f;
                    angleToPush.X += .2f;
                }
            }
            Vector3 angleToShow = angleToPush + position;
            //view = Matrix.CreateLookAt(new Vector3(position.X,position.Y + 20,position.Z + 15),position,Vector3.UnitY);
            view = Matrix.CreateLookAt(angleToShow, position, Vector3.UnitY);
            world = Matrix.CreateRotationZ(angle) * Matrix.CreateRotationX((3.14159f / 2) + 3.14159f) * Matrix.CreateTranslation(position);

            sword.swordUpdate(position,angle);
            gun.gunUpdate(position, angle);
            gui.updateGui();

            crate[0, 0].checkCollision(playerBoundry);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            DrawModel(model, world, view, projection);
            DrawModel(sword.getModel(), sword.getWorld(), view, projection);
            DrawModel(gun.getModel(), gun.getWorld(), view, projection);


            /*
            DrawModel(box.getModel(), box.getWorld(), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(6, 0, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-4, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-6, -2, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(4, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(2, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(0, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-2, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-4, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(-6, -4, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(6, -2, 0)), view, projection);
            DrawModel(box.getModel(), Matrix.CreateTranslation(new Vector3(6, -4, 0)), view, projection);
            */

            for (int x = 0; x <= 29; x++)
            {
                for (int y = 0; y <= 29; y++)
                {
                    DrawModel(crate[x, y].getModel(), crate[x, y].getWorld(), view, projection);
                    if (crate[x, y].getType() == 10)
                        DrawModel(crate[x, y].getModelTwo(), Matrix.CreateTranslation(new Vector3(crate[x, y].getPosition().X - 1.5f, -6f, crate[x, y].getPosition().Z - 1.5f)), view, projection);
                }
            }

            gui.drawGui(spriteBatch);
            GraphicsDevice.BlendState = BlendState.Opaque;
            GraphicsDevice.DepthStencilState = DepthStencilState.Default;
            GraphicsDevice.SamplerStates[0] = SamplerState.LinearWrap;
            base.Draw(gameTime);
        }

        public Vector2 changeAngleToVector(float angle)
        {
            return new Vector2((float)Math.Sin(angle), (float)Math.Cos(angle));
        }

        private void DrawModel(Model model, Matrix world, Matrix view, Matrix projection)
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.World = world;
                    effect.View = view;
                    effect.Projection = projection;
                }
                mesh.Draw();
            }
        }
    }
}