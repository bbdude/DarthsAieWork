﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace _3DModel
{
    internal class Crate
    {
        private Model model;
        private Model modelTwo;
        private Matrix world = Matrix.CreateTranslation(new Vector3(6, 0, 0));
        private Vector3 position = Vector3.Zero;
        private int crateType = 0;
        BoundingBox crateBoundry;

        public Crate(Model theModel, Vector3 whereAt)
        {
            model = theModel;
            world = Matrix.CreateTranslation(whereAt);
            position = whereAt;
        }

        public void reloadModel(Model theModel)
        {
            model = theModel;
        }

        public void reloadModelTwo(Model theModel)
        {
            modelTwo = theModel;
        }

        public void boxUpdate()
        {
            crateBoundry = new BoundingBox(position,new Vector3(6,6,6));
            world = Matrix.CreateTranslation(position);
        }

        public Model getModel()
        {
            return model;
        }

        public Model getModelTwo()
        {
            return modelTwo;
        }

        public Matrix getWorld()
        {
            return world;
        }

        public int getType()
        {
            return crateType;
        }

        public Vector3 getPosition()
        {
            return position;
        }

        public void setType(int type)
        {
            crateType = type;
        }

        public void setWorldX(float x)
        {
            position.X = x;
            world = Matrix.CreateTranslation(position);
        }

        public void setWorldY(float y)
        {
            position.Y = y;
            world = Matrix.CreateTranslation(position);
        }

        public void setWorldZ(float z)
        {
            position.Z = z;
            world = Matrix.CreateTranslation(position);
        }
        public bool checkCollision(BoundingBox playerBoundry)
        {

            if (playerBoundry.Intersects(crateBoundry))
            {
                position.X += 20;
                Console.Write("Boom");
            }
            /*BoundingSphere bulletSphere = new BoundingSphere(currentBullet.position, 0.05f);
            CollisionType colType = CheckCollision(bulletSphere);
            if (colType != CollisionType.None)
            {
                bulletList.RemoveAt(i);
                i--;

                if (colType == CollisionType.Target)
                    gameSpeed *= 1.05f;
            }
             */
            return true;
        }
        public bool checkCollision(Vector2 playerPos)
        {
            float ax2 = playerPos.X + 1;
            float ay2 = playerPos.Y + 1;
            float bx2 = playerPos.X + 6;
            float by2 = playerPos.Y + 6;

            return position.X < bx2 && ax2 > playerPos.X && position.Y < by2 && ay2 > playerPos.Y;
        }
        /*
         function CheckCollision(ax1,ay1,aw,ah, bx1,by1,bw,bh)
         local ax2,ay2,bx2,by2 = ax1 + aw, ay1 + ah, bx1 + bw, by1 + bh
         return ax1 < bx2 and ax2 > bx1 and ay1 < by2 and ay2 > by1
         */
    }
}